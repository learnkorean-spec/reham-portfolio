REHAM ELSHRKAWY — CV FOLDER  (updated 2 Oct 2026)
Portfolio: https://reham-elshrkawy.vercel.app
LinkedIn:  https://www.linkedin.com/in/rehamelshrkawy

WHICH CV TO USE
1_Designed  -> email to recruiters, LinkedIn Featured, direct sends
   AllRound ............ unsure / mixed roles
   Operations_O2C ...... order-to-cash, order management, SSC, AR
   Procurement ......... buyer, purchasing, supplier, material planning
   Korean_Speaking ..... any Korean-language role
   Client_Operations ... client support, trading support, escalations
   Digital ............. digital projects, web, e-commerce, SEO

2_Simple ATS -> Workday, SuccessFactors, Taleo and big job portals
   SAP ......... operations / O2C / procurement / customer roles
   Marketing ... digital / marketing / e-commerce roles

3_Tailored -> the exact company it is named after
   Procurement_Starion ......... Starion Poland (closes 4 Oct 2026)
   Korean_CS_Logistics_Etex .... Etex Dubai
   Customer_Account_HPE ........ HPE Kuala Lumpur

-------------------------------------------------
أي CV أستخدم؟
1_Designed  = الإيميل وLinkedIn والإرسال المباشر
2_Simple ATS = بوابات التقديم الكبيرة مثل Workday
3_Tailored  = الشركة المكتوب اسمها على الملف فقط
